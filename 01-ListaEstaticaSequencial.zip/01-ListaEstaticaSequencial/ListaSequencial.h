//Arquivo ListaSequencial.h

#define MAX 10

struct aluno{
    int matricula;
    char nome [30];
    float n1, n2, n3, n4;
};

typedef struct lista Lista;

//Estrutura inicial da lista
Lista* cria_lista();
void libera_lista();

//Informacoes da Lista
int tamanho_lista(Lista* li);
int lista_cheia(Lista* li);
int lista_vazia(Lista* li);

//Insercoes de elementos
int insere_lista_final(Lista* li, struct  aluno al);

//Mensagens
void menu();

